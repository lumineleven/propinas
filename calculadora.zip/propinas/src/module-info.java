/**
 * 
 */
/**
 * 
 */
module propinas {
	requires java.desktop;
}